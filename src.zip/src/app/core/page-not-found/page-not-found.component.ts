import { Component } from '@angular/core';

@Component({
  template: `<div><h1 style="color: #4e5004cc">Opsss... Page not found</h1></div>`
})
export class PageNotFoundComponent {}
