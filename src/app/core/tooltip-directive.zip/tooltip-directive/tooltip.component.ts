import {Component} from '@angular/core';
import {TooltipPosition} from './tooltip.interface';

@Component({
  template:
    `<div class="money-tooltip-container"
            [ngStyle]="styles"
            [ngClass]="position"
          #tooltipContainer>
    {{template}}
      </div>`,
  styles: [
    `.money-tooltip-container {
      position: absolute;
      z-index: 999;
      padding: 8px;
      background: #333333;
      color: #fff;
      border-radius: 5px;
    }
    .money-tooltip-container.top:before {
      content: "";
      width: 0%;
      height: 0%;
      top: 100%;
      left: 50%; right: 50%;
      transform: translate(-50%, -50%);
      position: absolute;
      border-top: 12px solid #333333;
      border-right: 12px solid transparent;
      border-left: 12px solid transparent;
    }`
  ]
})
export class MoneyTooltipComponent {
  public styles = {};
  public position: TooltipPosition = 'top';
  public template = 'Hello';
}
